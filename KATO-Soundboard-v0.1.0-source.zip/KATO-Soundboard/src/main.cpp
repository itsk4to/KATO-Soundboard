#include <windows.h>
#include <commdlg.h>
#include <d3d11.h>
#include <shellapi.h>
#include <vector>
#include <string>
#include <filesystem>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include "audio_engine.h"
#pragma comment(lib,"d3d11.lib")
static ID3D11Device*dev{};static ID3D11DeviceContext*ctx{};static IDXGISwapChain*swap{};static ID3D11RenderTargetView*rt{};static HWND hwnd{};
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
static void Target(){ID3D11Texture2D*b{};swap->GetBuffer(0,IID_PPV_ARGS(&b));dev->CreateRenderTargetView(b,nullptr,&rt);b->Release();}
static void ClearTarget(){if(rt){rt->Release();rt=nullptr;}}
static LRESULT WINAPI WndProc(HWND h,UINT m,WPARAM w,LPARAM l){
 if(ImGui_ImplWin32_WndProcHandler(h,m,w,l))return 1;
 if(m==WM_SIZE&&dev&&w!=SIZE_MINIMIZED){ClearTarget();swap->ResizeBuffers(0,LOWORD(l),HIWORD(l),DXGI_FORMAT_UNKNOWN,0);Target();return 0;}
 if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,w,l);
}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE,PWSTR,int){
 WNDCLASSEXW wc{sizeof(wc),CS_CLASSDC,WndProc,0,0,inst};wc.lpszClassName=L"KATO_SB";RegisterClassExW(&wc);
 hwnd=CreateWindowW(wc.lpszClassName,L"KATO Soundboard",WS_OVERLAPPEDWINDOW,120,100,1100,720,nullptr,nullptr,inst,nullptr);
 DXGI_SWAP_CHAIN_DESC sd{};sd.BufferCount=2;sd.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;sd.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;sd.OutputWindow=hwnd;sd.SampleDesc.Count=1;sd.Windowed=TRUE;
 D3D_FEATURE_LEVEL fl{};if(FAILED(D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&sd,&swap,&dev,&fl,&ctx)))return 1;
 Target();ShowWindow(hwnd,SW_SHOW);
 IMGUI_CHECKVERSION();ImGui::CreateContext();ImGui::StyleColorsDark();ImGui::GetStyle().WindowRounding=8;
 ImGui_ImplWin32_Init(hwnd);ImGui_ImplDX11_Init(dev,ctx);
 AudioEngine audio;audio.Initialize();
 std::vector<std::filesystem::path> paths;std::vector<std::string> names;std::string status="Ready";
 float master=.85f,mon=.75f,mic=1.f;bool monitor=true,virtualMic=true,done=false;MSG msg{};
 while(!done){while(PeekMessageW(&msg,nullptr,0,0,PM_REMOVE)){TranslateMessage(&msg);DispatchMessageW(&msg);if(msg.message==WM_QUIT)done=true;}if(done)break;
 ImGui_ImplDX11_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();
 ImGui::SetNextWindowPos({0,0});ImGui::SetNextWindowSize(ImGui::GetIO().DisplaySize);
 ImGui::Begin("KATO Soundboard",nullptr,ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoCollapse);
 ImGui::TextColored({.2f,.7f,1,1},"KATO");ImGui::SameLine();ImGui::TextDisabled("SOUNDBOARD  /  v0.1.0");ImGui::Separator();
 if(ImGui::Button("+ Import Audio")){
  wchar_t buf[32768]={};OPENFILENAMEW ofn{};ofn.lStructSize=sizeof(ofn);ofn.hwndOwner=hwnd;ofn.lpstrFilter=L"Audio\0*.wav;*.mp3;*.flac;*.ogg;*.m4a\0All\0*.*\0";ofn.lpstrFile=buf;ofn.nMaxFile=32768;ofn.Flags=OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_ALLOWMULTISELECT;
  if(GetOpenFileNameW(&ofn)){std::filesystem::path first(buf);wchar_t*p=buf+wcslen(buf)+1;if(!*p){std::string e;if(audio.Import(first,e)){paths.push_back(first);names.push_back(first.stem().string());status="Imported "+first.filename().string();}else status=e;}
   else while(*p){auto file=first/p;std::string e;if(audio.Import(file,e)){paths.push_back(file);names.push_back(file.stem().string());status="Imported audio";}else status=e;p+=wcslen(p)+1;}}
 }
 ImGui::SameLine();if(ImGui::Button("STOP ALL")){audio.StopAll();status="Stopped";}
 ImGui::Separator();ImGui::BeginChild("pads",{0,ImGui::GetContentRegionAvail().y-145},true);
 int cols=std::max(1,(int)(ImGui::GetContentRegionAvail().x/170));int col=0;
 for(size_t i=0;i<names.size();i++){if(col)ImGui::SameLine();ImGui::PushID((int)i);if(ImGui::Button(names[i].c_str(),{155,78})){audio.Play(i);status="Playing: "+names[i];}ImGui::PopID();if(++col>=cols)col=0;}
 ImGui::EndChild();ImGui::Separator();
 if(ImGui::SliderFloat("Master",&master,0,1)||ImGui::SliderFloat("Headphones",&mon,0,1)||ImGui::SliderFloat("Virtual Mic",&mic,0,1))audio.SetMix(master,mon,mic,monitor,virtualMic);
 ImGui::Checkbox("Monitor on headphones",&monitor);ImGui::SameLine();ImGui::Checkbox("Send to virtual microphone",&virtualMic);audio.SetMix(master,mon,mic,monitor,virtualMic);
 ImGui::TextDisabled("Status: %s",status.c_str());
 ImGui::TextWrapped("Choose the VB-CABLE playback endpoint as the app's virtual-mic output, then select CABLE Output as the microphone in your game. Device picker and global hotkey editor are planned for the next iteration.");
 ImGui::End();ImGui::Render();float c[4]={.035f,.04f,.065f,1};ctx->OMSetRenderTargets(1,&rt,nullptr);ctx->ClearRenderTargetView(rt,c);ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());swap->Present(1,0);
 }
 audio.Shutdown();ImGui_ImplDX11_Shutdown();ImGui_ImplWin32_Shutdown();ImGui::DestroyContext();ClearTarget();swap->Release();ctx->Release();dev->Release();DestroyWindow(hwnd);UnregisterClassW(wc.lpszClassName,inst);return 0;
}
