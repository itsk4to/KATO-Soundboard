#pragma once
#include <windows.h>
#include <miniaudio.h>
#include <filesystem>
#include <mutex>
#include <string>
#include <vector>

class AudioEngine {
    struct Clip { std::vector<float> pcm; ma_uint64 frames{}; };
    struct Voice { size_t clip{}; ma_uint64 cursor{}; bool active{}; };
    struct CallbackContext { AudioEngine* self{}; bool mic{}; };
    ma_device monitor_{}, mic_{};
    CallbackContext monitorCtx_{this,false}, micCtx_{this,true};
    bool monitorStarted_{}, micStarted_{};
    std::vector<Clip> clips_;
    std::vector<Voice> monitorVoices_, micVoices_;
    std::mutex mutex_;
    float master_{0.85f}, monitorGain_{0.75f}, micGain_{1.0f};
    bool monitorOn_{true}, micOn_{true};
    static void Callback(ma_device*, void*, const void*, ma_uint32);
    void Mix(float*, ma_uint32, bool);
    bool Start(ma_device&, CallbackContext&, const std::wstring&);
public:
    ~AudioEngine();
    bool Initialize(const std::wstring& monitorDevice=L"", const std::wstring& micDevice=L"");
    bool Import(const std::filesystem::path&, std::string& error);
    void Play(size_t);
    void StopAll();
    void SetMix(float master,float monitor,float mic,bool monitorOn,bool micOn);
    void Shutdown();
};
