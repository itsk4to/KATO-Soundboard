#include <nlohmann/json.hpp>
#include <filesystem>
#include <fstream>
#include <cstdlib>
#include <string>
#include <vector>
struct Pad { std::string name,path; int hotkey=0; };
static std::filesystem::path ProfileDir(){
 const char*a=std::getenv("APPDATA");return (a?std::filesystem::path(a):std::filesystem::temp_directory_path())/"KATO"/"Soundboard"/"profiles";
}
bool SaveProfile(const std::string& name,const std::vector<Pad>& pads,std::string& error){
 try{std::filesystem::create_directories(ProfileDir());nlohmann::json j;j["name"]=name;j["pads"]=nlohmann::json::array();
 for(auto&p:pads)j["pads"].push_back({{"name",p.name},{"path",p.path},{"hotkey",p.hotkey}});
 std::ofstream f(ProfileDir()/(name+".json"));if(!f){error="Cannot save profile";return false;}f<<j.dump(2);return true;
 }catch(const std::exception&e){error=e.what();return false;}
}
