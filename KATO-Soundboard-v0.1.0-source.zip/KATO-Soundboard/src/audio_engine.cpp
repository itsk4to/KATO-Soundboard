#include "audio_engine.h"
#include <algorithm>
#include <cmath>

AudioEngine::~AudioEngine(){Shutdown();}
bool AudioEngine::Start(ma_device& dev, CallbackContext& ctx, const std::wstring& name){
    ma_device_config c=ma_device_config_init(ma_device_type_playback);
    c.playback.format=ma_format_f32; c.playback.channels=2; c.sampleRate=48000;
    c.dataCallback=Callback; c.pUserData=&ctx;
    ma_context mc; if(ma_context_init(nullptr,0,nullptr,&mc)!=MA_SUCCESS)return false;
    ma_device_info* infos=nullptr; ma_uint32 count=0;
    if(ma_context_get_devices(&mc,&infos,&count,nullptr,nullptr)==MA_SUCCESS && !name.empty()){
        for(ma_uint32 i=0;i<count;i++) if(name==infos[i].name){c.playback.pDeviceID=&infos[i].id;break;}
    }
    ma_result r=ma_device_init(&mc,&c,&dev); ma_context_uninit(&mc);
    return r==MA_SUCCESS && ma_device_start(&dev)==MA_SUCCESS;
}
bool AudioEngine::Initialize(const std::wstring& monitor,const std::wstring& mic){
    Shutdown(); monitorStarted_=Start(monitor_,monitorCtx_,monitor);
    micStarted_=Start(mic_,micCtx_,mic); return monitorStarted_||micStarted_;
}
bool AudioEngine::Import(const std::filesystem::path& p,std::string& error){
    ma_decoder_config cfg=ma_decoder_config_init(ma_format_f32,2,48000); ma_decoder d{};
    if(ma_decoder_init_file_w(p.c_str(),&cfg,&d)!=MA_SUCCESS){error="Cannot decode this audio file.";return false;}
    ma_uint64 n=0; ma_decoder_get_length_in_pcm_frames(&d,&n);
    if(!n||n>48000ULL*60*20){ma_decoder_uninit(&d);error="Empty or longer than 20 minutes.";return false;}
    Clip c; c.pcm.resize((size_t)n*2); ma_uint64 got=0;
    ma_result r=ma_decoder_read_pcm_frames(&d,c.pcm.data(),n,&got); ma_decoder_uninit(&d);
    if(r!=MA_SUCCESS||!got){error="Audio decode failed.";return false;}
    c.frames=got;c.pcm.resize((size_t)got*2);
    std::scoped_lock l(mutex_);clips_.push_back(std::move(c));
    monitorVoices_.resize(clips_.size());micVoices_.resize(clips_.size());return true;
}
void AudioEngine::Play(size_t i){std::scoped_lock l(mutex_);if(i>=clips_.size())return;
    monitorVoices_[i]={i,0,true};micVoices_[i]={i,0,true};}
void AudioEngine::StopAll(){std::scoped_lock l(mutex_);for(auto&v:monitorVoices_)v.active=false;for(auto&v:micVoices_)v.active=false;}
void AudioEngine::SetMix(float a,float b,float c,bool d,bool e){std::scoped_lock l(mutex_);
    master_=std::clamp(a,0.f,1.f);monitorGain_=std::clamp(b,0.f,1.f);micGain_=std::clamp(c,0.f,1.f);monitorOn_=d;micOn_=e;}
void AudioEngine::Callback(ma_device* d,void* out,const void*,ma_uint32 n){
    auto*c=(CallbackContext*)d->pUserData;if(c&&c->self)c->self->Mix((float*)out,n,c->mic);
}
void AudioEngine::Mix(float*out,ma_uint32 n,bool mic){
    std::fill(out,out+(size_t)n*2,0.f);std::scoped_lock l(mutex_);
    if((mic&&!micOn_)||(!mic&&!monitorOn_))return;
    auto&vs=mic?micVoices_:monitorVoices_;float gain=master_*(mic?micGain_:monitorGain_);
    for(auto&v:vs){if(!v.active||v.clip>=clips_.size())continue;auto&c=clips_[v.clip];
        for(ma_uint32 f=0;f<n;f++){if(v.cursor>=c.frames){v.active=false;break;}
            size_t s=(size_t)v.cursor++*2;out[(size_t)f*2]+=c.pcm[s]*gain;out[(size_t)f*2+1]+=c.pcm[s+1]*gain;}}
    for(size_t i=0;i<(size_t)n*2;i++)out[i]=std::tanh(out[i]);
}
void AudioEngine::Shutdown(){if(monitorStarted_){ma_device_uninit(&monitor_);monitorStarted_=false;}
    if(micStarted_){ma_device_uninit(&mic_);micStarted_=false;}}
