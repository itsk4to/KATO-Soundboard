# KATO Soundboard — C++ Windows prototype

**Current status: prototype source, not a finished/release-ready application.**

### Included
- Dark Dear ImGui + Direct3D 11 desktop shell
- Multi-select audio import
- Audio decoding via miniaudio (48 kHz stereo float)
- Two playback stream code paths; the current UI prototype still needs a real device picker and explicit endpoint routing before it can act as a verified virtual microphone
- Master, headphone and virtual-mic gain controls
- Stop All
- JSON profile-save foundation (`src/profile.cpp`)

### Build
Requirements: Windows 10/11 x64, Visual Studio 2022 (Desktop development with C++), CMake 3.24+, internet on first configure.

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```

Output: `build/Release/KATOSoundboard.exe`

### Virtual microphone
Install VB-CABLE only from the official VB-Audio website. After the device picker is implemented, the app must send audio to the `CABLE Input` playback device; in a game, select `CABLE Output` as the microphone/recording input. Keep headphones selected as the monitor output.

### Work still required before release
- Proper device picker and hot-plug recovery
- Global hotkey capture, assignment, persistence and conflict detection
- Full profile manager (create/load/rename/delete and reload clips)
- Per-pad volume, loop/toggle modes, waveform preview and search
- Lock-free audio callback (current callback uses a mutex; not ideal for production latency)
- Audio-device synchronization testing, installer, signing and Windows QA
- Test with target games and voice applications

The source uses FetchContent to retrieve Dear ImGui, miniaudio and nlohmann/json during CMake configuration.
